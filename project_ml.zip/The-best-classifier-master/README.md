# The-best-classifier

In this notebook I have tried to use all the classification algorithms that I have learned in Machine Learning with Python course authorized by IBM.
